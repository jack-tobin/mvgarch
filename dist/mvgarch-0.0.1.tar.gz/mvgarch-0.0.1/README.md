# mvgarch
Multivariate GARCH modelling in Python
